Hi,

You tried to submit a pull request for adblockplusui.

While we love GitHub, the project is hosted on GitLab, therefore we do
not monitor pull request submitted on GitHub.

Please visit: https://gitlab.com/eyeo/adblockplus/abpui/adblockplusui

Thank you.
