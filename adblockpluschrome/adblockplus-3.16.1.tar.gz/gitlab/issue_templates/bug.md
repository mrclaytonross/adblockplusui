## Environment
- **OS version:** (e.g. Windows 10)
- **Browser version:** (e.g. Firefox 51)
- **Extension version:** (e.g. Adblock Plus 3.6; UI release 2019-1)
- **Last working version:** (e.g. Adblock Plus 3.5)

## Steps to reproduce
1. (e.g. Open Advanced tab in desktop settings page)
2. (e.g. Add custom filter `foo`)

## Observed behavior
(Describe the experienced behavior when following the above steps)

## Expected behavior
(Describe the behavior that is expected when following the above steps)

## Further information
(Mention any further information here, such as what led to the bug)

/label ~"🐛 bug" ~"Product:: ABP"
