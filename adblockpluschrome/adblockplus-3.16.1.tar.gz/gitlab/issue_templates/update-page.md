## Background

This ticket mentions changes for the %MILESTONE release that we would like to announce to our users in the [updates page](https://gitlab.com/eyeo/specs/spec/-/blob/master/spec/abp/updates.md).

## List of Improvements

(Add issue links for [relevant changes](https://gitlab.com/eyeo/adblockplus/abpui/adblockplusui/-/wikis/release-workflow#update-specific-changes) to this list)

- #000

## List of Fixes

(Add issue links for [relevant fixes](https://gitlab.com/eyeo/adblockplus/abpui/adblockplusui/-/wikis/release-workflow#update-specific-changes) to this list)

- #000

## What to change

- **Spec:** ([Create spec merge request](https://gitlab.com/eyeo/specs/spec/merge_requests/new) for [changes to the updates page](https://gitlab.com/eyeo/adblockplus/abpui/adblockplusui/-/wikis/release-workflow#update-specific-changes) and link to it from here)
- **Legal:** (Link to JIRA ticket with Legal's approval)

/milestone %MILESTONE
/label ~"Product:: ABP"
