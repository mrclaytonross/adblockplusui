This directory contains mocks for the code found in `/adblockpluschrome/ext`.
